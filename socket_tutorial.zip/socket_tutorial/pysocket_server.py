#!/usr/bin/env python
# -*- coding:utf-8 -*-
import socket
import random
import json
import  chardet
import sys

HOST = ''
POST = 3359
print POST
ADDRESS = (HOST,POST)
File_json = open('my.json')
json_data = json.load(File_json)
data_str= json.dumps(json_data,ensure_ascii=False,indent=2)
# str.decode("utf-8")
# print data_str
Send_data= (data_str.encode("utf-8") )
dict = {'1':'a'}
print type(dict)

# print(chardet.detect(json_datastr))






sock= socket.socket(socket.AF_INET,socket.SOCK_STREAM)
sock.bind(ADDRESS)
sock.listen(5)
print 'waiting connecting...'
while 1:
    coon,addr = sock.accept()
    print addr[0]
    while 1:
        data = coon.recv(1024)
        print 'recv data:',data
        fi= file('read.json','w')
        fi.write(data)

        coon.sendall(Send_data)
        # coon.sendall('cpr\r\n')


